import { createBrowserClient } from "@supabase/ssr"

export function createClient() {
  const url = "https://wsarfmdccsvcrngocds.supabase.co"
  const key =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzYXJmbWRjY3N2Y3JuZ29jZHNyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIwMTczNzMsImV4cCI6MjA3NzU5MzM3M30.vDX7dwnMb8VxhZ1-E2QNsLMzV3tjfwrGSP1ivTxunY0"

  if (!url || !key) {
    console.error("[v0] Supabase URL or API key is missing!")
    return null as any
  }

  return createBrowserClient(url, key)
}
