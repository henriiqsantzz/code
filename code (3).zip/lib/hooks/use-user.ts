"use client"

import { useEffect, useState } from "react"

export function useUser() {
  const [user, setUser] = useState<any>(null)
  const [userDetails, setUserDetails] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    setUserDetails({
      id: "user-123",
      balance: 1000,
      name: "Usuário",
      email: "user@example.com",
    })
    setLoading(false)
  }, [])

  return { user, userDetails, loading }
}
