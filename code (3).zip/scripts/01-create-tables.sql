-- Criação das tabelas principais para o sistema de investimentos

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  document VARCHAR(20) UNIQUE,
  balance DECIMAL(15, 2) DEFAULT 0.00,
  withdrawal_balance DECIMAL(15, 2) DEFAULT 0.00,
  role VARCHAR(50) DEFAULT 'user', -- 'user' or 'admin'
  pix_key VARCHAR(255),
  pix_key_type VARCHAR(50), -- 'email', 'cpf', 'phone', 'random'
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de transações de depósito
CREATE TABLE IF NOT EXISTS deposits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount DECIMAL(15, 2) NOT NULL,
  payment_method VARCHAR(50) DEFAULT 'PIX',
  status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'completed', 'failed'
  pix_qr_code TEXT,
  pix_copy_paste TEXT,
  transaction_id VARCHAR(255) UNIQUE,
  external_transaction_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de transações de saque
CREATE TABLE IF NOT EXISTS withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount DECIMAL(15, 2) NOT NULL,
  amount_net DECIMAL(15, 2) NOT NULL,
  amount_fee DECIMAL(15, 2) NOT NULL,
  pix_key VARCHAR(255) NOT NULL,
  pix_key_type VARCHAR(50) NOT NULL,
  status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'completed', 'failed'
  transaction_id VARCHAR(255) UNIQUE,
  external_transaction_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabela de investimentos
CREATE TABLE IF NOT EXISTS investments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_type VARCHAR(100) NOT NULL, -- 'petroliferos', 'gas', 'eventos'
  product_name VARCHAR(255) NOT NULL,
  investment_amount DECIMAL(15, 2) NOT NULL,
  payment_method VARCHAR(50) NOT NULL, -- 'balance' or 'withdrawal'
  daily_return DECIMAL(10, 2) NOT NULL,
  total_days INT NOT NULL,
  total_expected_return DECIMAL(15, 2) NOT NULL,
  status VARCHAR(50) DEFAULT 'active', -- 'active', 'completed', 'cancelled'
  created_at TIMESTAMP DEFAULT NOW(),
  completed_at TIMESTAMP,
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Criar índices para melhor performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_deposits_user_id ON deposits(user_id);
CREATE INDEX idx_deposits_status ON deposits(status);
CREATE INDEX idx_withdrawals_user_id ON withdrawals(user_id);
CREATE INDEX idx_withdrawals_status ON withdrawals(status);
CREATE INDEX idx_investments_user_id ON investments(user_id);
CREATE INDEX idx_investments_status ON investments(status);

-- Habilitar RLS (Row Level Security)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE deposits ENABLE ROW LEVEL SECURITY;
ALTER TABLE withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE investments ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para usuários
CREATE POLICY "Users can view their own data" ON users
  FOR SELECT USING (auth.uid()::text = id::text OR (SELECT role FROM users WHERE id = auth.uid()::uuid) = 'admin');

CREATE POLICY "Users can update their own data" ON users
  FOR UPDATE USING (auth.uid()::text = id::text);

-- Políticas RLS para depósitos
CREATE POLICY "Users can view their own deposits" ON deposits
  FOR SELECT USING (user_id = auth.uid()::uuid OR (SELECT role FROM users WHERE id = auth.uid()::uuid) = 'admin');

CREATE POLICY "Users can create deposits" ON deposits
  FOR INSERT WITH CHECK (user_id = auth.uid()::uuid);

-- Políticas RLS para saques
CREATE POLICY "Users can view their own withdrawals" ON withdrawals
  FOR SELECT USING (user_id = auth.uid()::uuid OR (SELECT role FROM users WHERE id = auth.uid()::uuid) = 'admin');

CREATE POLICY "Users can create withdrawals" ON withdrawals
  FOR INSERT WITH CHECK (user_id = auth.uid()::uuid);

-- Políticas RLS para investimentos
CREATE POLICY "Users can view their own investments" ON investments
  FOR SELECT USING (user_id = auth.uid()::uuid OR (SELECT role FROM users WHERE id = auth.uid()::uuid) = 'admin');

CREATE POLICY "Users can create investments" ON investments
  FOR INSERT WITH CHECK (user_id = auth.uid()::uuid);
