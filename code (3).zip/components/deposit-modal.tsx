"use client"

import { useState } from "react"
import { X, Copy, Check } from "lucide-react"
import QRCode from "qrcode"
import { Button } from "@/components/ui/button"

interface DepositModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (amount: number) => void
}

const PRESET_AMOUNTS = [40, 50, 100, 200, 500, 1000, 2000, 3000, 5000, 10000, 20000, 50000]
const MIN_DEPOSIT = 40
const MAX_DEPOSIT = 50000

export function DepositModal({ isOpen, onClose, onConfirm }: DepositModalProps) {
  const [amount, setAmount] = useState("")
  const [qrCode, setQrCode] = useState<string | null>(null)
  const [pixKey, setPixKey] = useState("usuario@email.com")
  const [copied, setCopied] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  if (!isOpen) return null

  const handleAmountChange = (value: string) => {
    const numValue = Number.parseFloat(value) || 0
    setAmount(value)
    setError("")
    setQrCode(null)
  }

  const handlePresetAmount = (presetAmount: number) => {
    setAmount(presetAmount.toString())
    setError("")
    setQrCode(null)
  }

  const validateAmount = (): boolean => {
    const numAmount = Number.parseFloat(amount)

    if (!amount || isNaN(numAmount)) {
      setError("Digite um valor válido")
      return false
    }

    if (numAmount < MIN_DEPOSIT) {
      setError(`Valor mínimo é R$ ${MIN_DEPOSIT}.00`)
      return false
    }

    if (numAmount > MAX_DEPOSIT) {
      setError(`Valor máximo é R$ ${MAX_DEPOSIT}.00`)
      return false
    }

    return true
  }

  const generateQRCode = async () => {
    if (!validateAmount()) return

    setLoading(true)
    try {
      const numAmount = Number.parseFloat(amount)
      // PIX static QR code - em produção, integrar com API real
      const pixData = `00020126580014br.gov.bcb.pix0136${pixKey}52040000530398654061${numAmount.toFixed(2)}5802BR5913INVESTALTO6009SAO PAULO62410503***63041D3D`

      const qrCodeUrl = await QRCode.toDataURL(pixData)
      setQrCode(qrCodeUrl)
    } catch (err) {
      setError("Erro ao gerar QR code")
    } finally {
      setLoading(false)
    }
  }

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(pixKey)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      setError("Erro ao copiar chave PIX")
    }
  }

  const handleConfirm = () => {
    if (validateAmount()) {
      onConfirm(Number.parseFloat(amount))
      onClose()
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-white rounded-[20px] max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-[#8BA3A3]/20 px-6 py-4 flex items-center justify-between rounded-t-[20px]">
          <h2 className="text-xl font-semibold text-[#1E1E1E]">Depósito</h2>
          <button onClick={onClose} className="text-[#5E6B6B] hover:text-[#1E1E1E] transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Valor do depósito */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-2">Valor do depósito</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => handleAmountChange(e.target.value)}
              placeholder="Valor do depósito"
              className="w-full px-4 py-2.5 rounded-lg border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C] transition-colors"
            />
            {error && <p className="text-sm text-red-600 mt-1">{error}</p>}
          </div>

          {/* Valores pré-definidos */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-3">Valores sugeridos</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {PRESET_AMOUNTS.map((presetAmount) => (
                <button
                  key={presetAmount}
                  onClick={() => handlePresetAmount(presetAmount)}
                  className={`py-2 px-3 rounded-lg border-2 transition-all ${
                    amount === presetAmount.toString()
                      ? "border-[#0A3C3C] bg-[#0A3C3C]/10 text-[#0A3C3C] font-medium"
                      : "border-[#8BA3A3]/20 text-[#5E6B6B] hover:border-[#0A3C3C]/30"
                  }`}
                >
                  R$ {presetAmount}
                </button>
              ))}
            </div>
          </div>

          {/* Método de depósito */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-3">Método de depósito</label>
            <div className="border border-[#8BA3A3]/20 rounded-lg p-4 bg-[#F5F5F5]">
              <p className="font-semibold text-[#1E1E1E] mb-3">wopay (PIX)</p>
              <p className="text-sm text-[#5E6B6B] mb-3">
                Intervalo de valores: R$ {MIN_DEPOSIT} - R$ {MAX_DEPOSIT}
              </p>
            </div>
          </div>

          {/* QR Code */}
          {qrCode && (
            <div className="space-y-3">
              <label className="block text-sm font-medium text-[#1E1E1E]">QR Code para pagamento</label>
              <div className="flex flex-col items-center gap-4">
                <img
                  src={qrCode || "/placeholder.svg"}
                  alt="QR Code PIX"
                  className="w-48 h-48 border border-[#8BA3A3]/20 rounded-lg p-2"
                />
                <div className="w-full">
                  <label className="block text-sm font-medium text-[#1E1E1E] mb-2">Ou copie a chave PIX</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={pixKey}
                      readOnly
                      className="flex-1 px-4 py-2.5 rounded-lg border border-[#8BA3A3]/20 bg-[#F5F5F5] text-[#5E6B6B] text-sm"
                    />
                    <Button
                      onClick={handleCopy}
                      className={`px-4 py-2.5 rounded-lg font-medium transition-all ${
                        copied
                          ? "bg-green-600 hover:bg-green-700 text-white"
                          : "bg-[#0A3C3C] hover:bg-[#0C5050] text-white"
                      }`}
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 mr-1" />
                          Copiado
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-1" />
                          Copiar
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Descrição da regra */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
            <p className="text-sm font-semibold text-blue-900">Descrição da regra</p>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>
                • Não altere o valor da recarga e certifique-se de transferir de acordo com o valor que iniciou a
                recarga.
              </li>
              <li>• Inicie cada recarga por meio desta página e não salve a conta de transferência.</li>
              <li>
                • Valor de recarga única entre R$ {MIN_DEPOSIT} e R$ {MAX_DEPOSIT}.
              </li>
              <li>
                • Se a recarga for iniciada há mais de 5 minutos, mas não for recebida, envie um problema de recarga não
                recebido por meio da central de ajuda de autoatendimento.
              </li>
              <li>
                • Devido à popularidade da plataforma, a inicialização da recarga pode falhar. Tente algumas vezes.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#8BA3A3]/20 p-6 space-y-3">
          <Button
            onClick={generateQRCode}
            disabled={!amount || loading}
            className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white py-2.5 rounded-lg font-medium transition-colors disabled:opacity-50"
          >
            {loading ? "Gerando QR Code..." : "Gerar QR Code"}
          </Button>
          <Button
            onClick={onClose}
            className="w-full bg-[#8BA3A3] hover:bg-[#7A9292] text-white py-2.5 rounded-lg font-medium transition-colors"
          >
            Cancelar
          </Button>
        </div>
      </div>
    </div>
  )
}
