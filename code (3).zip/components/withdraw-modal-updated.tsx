"use client"

import { useState } from "react"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface WithdrawModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (amount: number, pixKey: string, pixKeyType: string) => void
  userBalance: number
}

const PIX_KEY_TYPES = [
  { value: "email", label: "Email" },
  { value: "cpf", label: "CPF" },
  { value: "phone", label: "Celular" },
  { value: "random", label: "Chave aleatória" },
]

const MIN_WITHDRAWAL = 50

export function WithdrawModal({ isOpen, onClose, onConfirm, userBalance }: WithdrawModalProps) {
  const [amount, setAmount] = useState("")
  const [pixKeyType, setPixKeyType] = useState("email")
  const [pixKey, setPixKey] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  if (!isOpen) return null

  const validateForm = (): boolean => {
    const numAmount = Number.parseFloat(amount)

    if (!amount || isNaN(numAmount)) {
      setError("Digite um valor válido")
      return false
    }

    if (numAmount < MIN_WITHDRAWAL) {
      setError(`Valor mínimo de saque é R$ ${MIN_WITHDRAWAL}.00`)
      return false
    }

    if (numAmount > userBalance) {
      setError("Saldo insuficiente")
      return false
    }

    if (!pixKey.trim()) {
      setError(`Digite sua ${PIX_KEY_TYPES.find((t) => t.value === pixKeyType)?.label.toLowerCase() || "chave PIX"}`)
      return false
    }

    return true
  }

  const handleConfirm = async () => {
    if (!validateForm()) return

    setLoading(true)
    try {
      onConfirm(Number.parseFloat(amount), pixKey, pixKeyType)
      setAmount("")
      setPixKey("")
      setError("")
      onClose()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao processar saque")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-[20px] max-w-md w-full" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="border-b border-[#8BA3A3]/20 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-[#1E1E1E]">Sacar</h2>
          <button onClick={onClose} className="text-[#5E6B6B] hover:text-[#1E1E1E]">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-1.5">Saldo disponível</label>
            <p className="text-2xl font-bold text-[#0A3C3C]">R$ {userBalance.toFixed(2)}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-1.5">Valor do saque</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value)
                setError("")
              }}
              placeholder="0.00"
              className="w-full px-4 py-2.5 rounded-lg border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-1.5">Tipo de chave PIX</label>
            <select
              value={pixKeyType}
              onChange={(e) => {
                setPixKeyType(e.target.value)
                setPixKey("")
                setError("")
              }}
              className="w-full px-4 py-2.5 rounded-lg border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
            >
              {PIX_KEY_TYPES.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-1.5">
              {PIX_KEY_TYPES.find((t) => t.value === pixKeyType)?.label}
            </label>
            <input
              type="text"
              value={pixKey}
              onChange={(e) => {
                setPixKey(e.target.value)
                setError("")
              }}
              placeholder={
                pixKeyType === "email"
                  ? "seu@email.com"
                  : pixKeyType === "cpf"
                    ? "12345678901"
                    : pixKeyType === "phone"
                      ? "+5511999999999"
                      : "Chave aleatória"
              }
              className="w-full px-4 py-2.5 rounded-lg border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
            />
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-xs text-blue-800">
              Taxa de saque: 2,5% • Você receberá R$ {Math.max(0, (Number.parseFloat(amount) || 0) * 0.975).toFixed(2)}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#8BA3A3]/20 p-6 space-y-3">
          <Button
            onClick={handleConfirm}
            disabled={loading}
            className="w-full bg-[#0A3C3C] hover:bg-[#0C5050] text-white py-2.5 rounded-lg font-medium disabled:opacity-50"
          >
            {loading ? "Processando..." : "Confirmar saque"}
          </Button>
          <Button
            onClick={onClose}
            className="w-full bg-[#8BA3A3] hover:bg-[#7A9292] text-white py-2.5 rounded-lg font-medium"
          >
            Cancelar
          </Button>
        </div>
      </div>
    </div>
  )
}
