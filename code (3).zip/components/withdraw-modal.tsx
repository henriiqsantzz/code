"use client"

import { useState } from "react"
import { X, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

interface WithdrawModalProps {
  isOpen: boolean
  onClose: () => void
}

const MIN_WITHDRAW = 50

export function WithdrawModal({ isOpen, onClose }: WithdrawModalProps) {
  const [amount, setAmount] = useState("")
  const [pixKey, setPixKey] = useState("")
  const [pixKeyType, setPixKeyType] = useState("email")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  if (!isOpen) return null

  const handleConfirm = async () => {
    setError("")
    setSuccess("")

    const numAmount = Number.parseFloat(amount)

    if (!amount || isNaN(numAmount)) {
      setError("Por favor, insira um valor válido")
      return
    }

    if (numAmount < MIN_WITHDRAW) {
      setError(`Valor mínimo de saque é R$ ${MIN_WITHDRAW}`)
      return
    }

    if (!pixKey.trim()) {
      setError("Por favor, insira sua chave PIX")
      return
    }

    try {
      setLoading(true)

      // CHANGE: Chamando API de saque
      const response = await fetch("/api/payments/withdraw", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: numAmount,
          pixKey: pixKey.trim(),
          pixKeyType: pixKeyType,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.message || "Erro ao processar saque")
        return
      }

      setSuccess("Saque processado com sucesso! Você receberá o valor em breve.")
      setAmount("")
      setPixKey("")

      setTimeout(() => {
        onClose()
        setSuccess("")
      }, 2000)
    } catch (err) {
      setError("Erro ao conectar com o servidor")
      console.error("[v0] Withdraw error:", err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="bg-white rounded-3xl w-full max-w-sm overflow-hidden">
        <div className="bg-gradient-to-r from-orange-400 to-red-500 px-6 py-4 flex items-center justify-between">
          <h3 className="text-lg font-bold text-white">Retirar</h3>
          <button onClick={onClose} className="text-white hover:opacity-80 transition-opacity">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Amount Input */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-2">Valor do saque</label>
            <Input
              type="number"
              placeholder="Valor do saque"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min={MIN_WITHDRAW}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>

          {/* PIX Key Type */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-2">Tipo de chave PIX</label>
            <select
              value={pixKeyType}
              onChange={(e) => setPixKeyType(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
            >
              <option value="email">Email</option>
              <option value="cpf">CPF</option>
              <option value="phone">Telefone</option>
              <option value="random">Chave Aleatória</option>
            </select>
          </div>

          {/* PIX Key Input */}
          <div>
            <label className="block text-sm font-medium text-[#1E1E1E] mb-2">Sua chave PIX</label>
            <Input
              type="text"
              placeholder="Digite sua chave PIX"
              value={pixKey}
              onChange={(e) => setPixKey(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>

          {/* Error Message */}
          {error && (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
              <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          {/* Success Message */}
          {success && (
            <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-lg px-3 py-2">
              <div className="w-4 h-4 text-green-600 flex-shrink-0">✓</div>
              <p className="text-sm text-green-600">{success}</p>
            </div>
          )}

          {/* Confirm Button */}
          <Button
            onClick={handleConfirm}
            disabled={loading}
            className="w-full bg-gradient-to-r from-orange-400 to-red-500 hover:from-orange-500 hover:to-red-600 text-white font-semibold py-3 rounded-full transition-all disabled:opacity-50"
          >
            {loading ? "Processando..." : "Confirmar"}
          </Button>
        </div>
      </Card>
    </div>
  )
}
