"use client"

import { Home, BarChart3, Users, Info, Pen, Coins, X, ImageIcon, BookOpen } from "lucide-react"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { useState } from "react"

export default function BlogPage() {
  const [posts, setPosts] = useState([
    {
      id: 1,
      author: "Marcelo Matos",
      date: "2025-10-31 13:07:25",
      content: "Obrigaduuu 👍👍😁",
      image: "/payment-receipt-screenshot.png",
      coins: 3,
      avatar: "MM",
    },
    {
      id: 2,
      author: "Juli",
      date: "2025-10-30 21:31:58",
      content: "Saque de hoje",
      image: "/withdrawal-screenshot-dark.jpg",
      coins: 2,
      avatar: "JU",
    },
    {
      id: 3,
      author: "Felipe Pessoa",
      date: "2025-10-30 21:21:54",
      content: "Pagamento de hoje obgda Sonangol e a melhor sempre tou recomendo para meus amigos 🤑",
      image: "/payment-proof.png",
      coins: 3,
      avatar: "FP",
    },
    {
      id: 4,
      author: "Marcelo Matos",
      date: "2025-10-30 12:59:25",
      content: "Recebi mais um pagamento hoje! Plataforma confiável 💰",
      image: "/payment-confirmation.png",
      coins: 4,
      avatar: "MM",
    },
  ])

  const [isModalOpen, setIsModalOpen] = useState(false)
  const [newPost, setNewPost] = useState({
    content: "",
    image: "",
  })

  const handleSubmitPost = () => {
    if (!newPost.content.trim()) return

    const now = new Date()
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")} ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`

    const post = {
      id: posts.length + 1,
      author: "Você",
      date: formattedDate,
      content: newPost.content,
      image: newPost.image || "/payment-receipt.png",
      coins: Math.floor(Math.random() * 3) + 2,
      avatar: "VC",
    }

    setPosts([post, ...posts])
    setNewPost({ content: "", image: "" })
    setIsModalOpen(false)
  }

  return (
    <div className="min-h-screen bg-[#C1D7D7] pb-24">
      {/* Posts Feed */}
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
        {posts.map((post) => (
          <Card key={post.id} className="bg-white rounded-[20px] p-4 shadow-sm border-0">
            {/* User Header */}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0A3C3C] to-[#0C5050] flex items-center justify-center text-white text-sm font-semibold">
                {post.avatar}
              </div>
              <div>
                <p className="text-sm font-semibold text-[#1E1E1E]">{post.author}</p>
                <p className="text-xs text-[#5E6B6B]">{post.date}</p>
              </div>
            </div>

            {/* Post Image */}
            <div className="mb-3">
              <img
                src={post.image || "/placeholder.svg"}
                alt="Post image"
                className="w-full max-w-[300px] h-auto rounded-xl object-cover"
              />
            </div>

            {/* Post Content */}
            <p className="text-sm text-[#1E1E1E] mb-3">{post.content}</p>

            {/* Coins Reward */}
            <div className="flex items-center gap-2 pt-3 border-t border-[#8BA3A3]/20">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center">
                <Coins className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm font-semibold text-[#1E1E1E]">+ {post.coins}</span>
              <span className="text-xs text-[#5E6B6B]">Tentam bayaran</span>
            </div>
          </Card>
        ))}
      </div>

      <button
        onClick={() => setIsModalOpen(true)}
        className="fixed bottom-24 right-6 w-14 h-14 rounded-full bg-[#0A3C3C] hover:bg-[#0C5050] shadow-lg flex items-center justify-center transition-colors z-40"
      >
        <Pen className="w-6 h-6 text-white" />
      </button>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-end md:items-center justify-center z-50 p-4">
          <div className="bg-white rounded-t-[30px] md:rounded-[20px] w-full max-w-lg p-6 animate-in slide-in-from-bottom duration-300">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-[#1E1E1E]">Criar Post</h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-[#C1D7D7] flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5 text-[#5E6B6B]" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-[#1E1E1E] mb-2 block">Mensagem</label>
                <textarea
                  value={newPost.content}
                  onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                  placeholder="Compartilhe sua experiência..."
                  className="w-full h-32 px-4 py-3 rounded-xl border border-[#8BA3A3]/30 focus:border-[#0A3C3C] focus:outline-none resize-none text-sm"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-[#1E1E1E] mb-2 block">URL da Imagem (opcional)</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newPost.image}
                    onChange={(e) => setNewPost({ ...newPost, image: e.target.value })}
                    placeholder="Cole o link da imagem..."
                    className="flex-1 px-4 py-3 rounded-xl border border-[#8BA3A3]/30 focus:border-[#0A3C3C] focus:outline-none text-sm"
                  />
                  <button className="w-12 h-12 rounded-xl bg-[#C1D7D7] hover:bg-[#8BA3A3] flex items-center justify-center transition-colors">
                    <ImageIcon className="w-5 h-5 text-[#0A3C3C]" />
                  </button>
                </div>
              </div>

              <button
                onClick={handleSubmitPost}
                disabled={!newPost.content.trim()}
                className="w-full py-3 rounded-xl bg-[#0A3C3C] hover:bg-[#0C5050] disabled:bg-[#8BA3A3] disabled:cursor-not-allowed text-white font-semibold transition-colors"
              >
                Publicar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fixed Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 md:px-8 py-3 md:py-4 rounded-t-[30px] md:rounded-none">
        <div className="max-w-7xl mx-auto flex items-center justify-around">
          <Link
            href="/casa"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Home className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">casa</span>
          </Link>
          <Link
            href="/"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors">
              <BarChart3 className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
            <span className="text-[10px] md:text-xs font-medium">Investir</span>
          </Link>
          <Link
            href="/clube"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Users className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">Clube</span>
          </Link>
          <Link
            href="/blog"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white hover:text-white transition-colors"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white flex items-center justify-center hover:bg-white/90 transition-colors">
              <BookOpen className="w-5 h-5 md:w-6 md:h-6 text-[#0A3C3C]" />
            </div>
            <span className="text-[10px] md:text-xs font-medium">Blog</span>
          </Link>
          <Link
            href="/nossa-historia"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Info className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">NossaHistória</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
