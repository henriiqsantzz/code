"use client"

import {
  Wallet,
  RefreshCw,
  User,
  BarChart3,
  Clock,
  TrendingUp,
  Home,
  Users,
  BookOpen,
  Info,
  ArrowRight,
  X,
  Award,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

const investmentLevels = [
  {
    name: "Bronze",
    color: "from-[#CD7F32] to-[#B87333]",
    minInvestment: 100,
    maxInvestment: 999,
    dailyReturn: "0.5%",
    benefits: ["Retorno diário de 0.5%", "Suporte básico", "Acesso a produtos petrolíferos"],
  },
  {
    name: "Prata",
    color: "from-[#C0C0C0] to-[#A8A8A8]",
    minInvestment: 1000,
    maxInvestment: 4999,
    dailyReturn: "0.8%",
    benefits: [
      "Retorno diário de 0.8%",
      "Suporte prioritário",
      "Acesso a todos os produtos",
      "Bônus de 5% no primeiro depósito",
    ],
  },
  {
    name: "Ouro",
    color: "from-[#FFD700] to-[#FFA500]",
    minInvestment: 5000,
    maxInvestment: null,
    dailyReturn: "1.2%",
    benefits: [
      "Retorno diário de 1.2%",
      "Suporte VIP 24/7",
      "Acesso exclusivo a produtos premium",
      "Bônus de 10% no primeiro depósito",
      "Gerente de conta dedicado",
    ],
  },
]

export default function PetroleumDashboard() {
  const router = useRouter()
  const [userBalance, setUserBalance] = useState(0)
  const [showInsufficientBalance, setShowInsufficientBalance] = useState(false)
  const [showLevelsModal, setShowLevelsModal] = useState(false)
  const [showInvestmentDetails, setShowInvestmentDetails] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null)
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<"balance" | "withdrawal">("balance")
  const [activeTab, setActiveTab] = useState<"petroliferos" | "gas" | "eventos">("petroliferos")
  const [loading, setLoading] = useState(true)
  const MIN_DEPOSIT = 50

  useEffect(() => {
    const fetchUserBalance = async () => {
      try {
        const supabase = createClient()
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (user) {
          const { data } = await supabase.from("users").select("balance").eq("id", user.id).single()

          if (data) {
            setUserBalance(data.balance || 0)
          }
        } else {
          setUserBalance(1000)
        }
      } catch (error) {
        console.log("[v0] Erro ao buscar saldo:", error)
        setUserBalance(1000)
      } finally {
        setLoading(false)
      }
    }

    fetchUserBalance()
  }, [])

  const handleInvest = (amount: number, productIndex: number) => {
    setSelectedProduct(productIndex)
    setSelectedPaymentMethod("balance")
    setShowInvestmentDetails(true)
  }

  const handleConfirmDetails = async () => {
    if (selectedProduct !== null) {
      const amount = currentProducts[selectedProduct].investment

      if (amount < MIN_DEPOSIT || userBalance < amount) {
        setShowInvestmentDetails(false)
        setShowInsufficientBalance(true)
      } else {
        try {
          const supabase = createClient()
          const {
            data: { user },
          } = await supabase.auth.getUser()

          if (user) {
            await supabase.from("investments").insert({
              user_id: user.id,
              product_type: activeTab,
              product_name: `${activeTab === "petroliferos" ? "Produtos petrolíferos" : activeTab === "gas" ? "Produtos de Gás Natural" : "Produtos para eventos"}`,
              investment_amount: amount,
              daily_return: currentProducts[selectedProduct].dailyIncome,
              total_days: currentProducts[selectedProduct].days,
              total_expected_return: currentProducts[selectedProduct].totalIncome,
              payment_method: selectedPaymentMethod,
              status: "active",
            })

            const newBalance = userBalance - amount
            await supabase.from("users").update({ balance: newBalance }).eq("id", user.id)

            setUserBalance(newBalance)
            setShowInvestmentDetails(false)

            alert("Investimento realizado com sucesso!")
          }
        } catch (error) {
          console.error("Erro ao processar investimento:", error)
          alert("Erro ao processar investimento")
        }
      }
    }
  }

  const handleRecharge = () => {
    setShowInsufficientBalance(false)
    router.push("/casa?scroll=recharge")
  }

  const products = {
    petroliferos: [
      {
        image: "/oil-rig-platform.jpg",
        investment: 40,
        days: 59,
        dailyIncome: 10,
        totalIncome: 590,
      },
      {
        image: "/offshore-oil-platform.jpg",
        investment: 80,
        days: 59,
        dailyIncome: 20,
        totalIncome: 1227.2,
      },
    ],
    gas: [
      {
        image: "/gas-natural-platform.jpg",
        investment: 50,
        days: 45,
        dailyIncome: 12,
        totalIncome: 540,
      },
    ],
    eventos: [
      {
        image: "/oil-rig-event.jpg",
        investment: 100,
        days: 30,
        dailyIncome: 25,
        totalIncome: 750,
      },
    ],
  }

  const currentProducts = products[activeTab]

  if (loading) {
    return (
      <div className="min-h-screen bg-[#C1D7D7] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 rounded-full border-4 border-[#8BA3A3]/20 border-t-[#0A3C3C] animate-spin mx-auto mb-4"></div>
          <p className="text-[#5E6B6B]">Carregando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#C1D7D7]">
      {/* Header */}
      <header className="flex items-center justify-between px-4 md:px-8 py-4 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <Wallet className="w-4 h-4 md:w-5 md:h-5 text-[#0A3C3C]" />
          <div>
            <p className="text-xs text-[#5E6B6B]">Carteira de depósito</p>
            <p className="text-base md:text-lg font-semibold text-[#1E1E1E]">≈ {userBalance.toFixed(2)} BRL</p>
          </div>
        </div>
        <div className="flex items-center gap-2 md:gap-3">
          <button
            onClick={() => setShowLevelsModal(true)}
            className="w-9 h-9 md:w-10 md:h-10 rounded-full bg-gradient-to-br from-[#FFD700] to-[#FFA500] flex items-center justify-center hover:opacity-90 transition-opacity"
          >
            <Award className="w-4 h-4 md:w-5 md:h-5 text-white" />
          </button>
          <button className="w-9 h-9 md:w-10 md:h-10 rounded-full bg-white/80 flex items-center justify-center hover:bg-white transition-colors">
            <User className="w-4 h-4 md:w-5 md:h-5 text-[#0A3C3C]" />
          </button>
          <button className="w-9 h-9 md:w-10 md:h-10 rounded-full bg-[#1E1E1E] flex items-center justify-center hover:bg-[#0A3C3C] transition-colors">
            <RefreshCw className="w-4 h-4 md:w-5 md:h-5 text-white" />
          </button>
        </div>
      </header>

      {/* Hero Card */}
      <div className="px-4 md:px-8 py-4 md:py-6">
        <Card className="bg-white rounded-[20px] p-4 md:p-6 shadow-sm border-0">
          <div className="flex items-start gap-3 md:gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-gradient-to-br from-[#0A3C3C] to-[#0C5050] flex items-center justify-center flex-shrink-0">
              <BarChart3 className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-semibold text-[#1E1E1E] mb-1 md:mb-2">Produtos petrolíferos</h1>
              <p className="text-xs md:text-sm text-[#5E6B6B] leading-relaxed">
                Produtos estáveis de alto rendimento, investimento contínuo com retornos sustentados.
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="px-4 md:px-8 pb-24 md:pb-28 grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-4 md:gap-6">
        {/* Sidebar Navigation */}
        <div className="space-y-2">
          <button
            onClick={() => setActiveTab("petroliferos")}
            className={`w-full flex items-center gap-3 px-3 md:px-4 py-2.5 md:py-3 rounded-xl transition-colors ${
              activeTab === "petroliferos" ? "bg-[#0A3C3C] text-white" : "bg-white/60 text-[#5E6B6B] hover:bg-white"
            }`}
          >
            <BarChart3 className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-xs md:text-sm font-medium">Produtos petrolíferos</span>
          </button>
          <button
            onClick={() => setActiveTab("gas")}
            className={`w-full flex items-center gap-3 px-3 md:px-4 py-2.5 md:py-3 rounded-xl transition-colors ${
              activeTab === "gas" ? "bg-[#0A3C3C] text-white" : "bg-white/60 text-[#5E6B6B] hover:bg-white"
            }`}
          >
            <Clock className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-xs md:text-sm font-medium">Produtos de Gás Natural</span>
          </button>
          <button
            onClick={() => setActiveTab("eventos")}
            className={`w-full flex items-center gap-3 px-3 md:px-4 py-2.5 md:py-3 rounded-xl transition-colors ${
              activeTab === "eventos" ? "bg-[#0A3C3C] text-white" : "bg-white/60 text-[#5E6B6B] hover:bg-white"
            }`}
          >
            <TrendingUp className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-xs md:text-sm font-medium">Produtos para eventos</span>
          </button>
        </div>

        {/* Product Cards */}
        <div className="space-y-4 md:space-y-6">
          {currentProducts.map((product, index) => (
            <Card key={index} className="bg-white rounded-[20px] p-4 md:p-6 shadow-sm border-0">
              <h3 className="text-base md:text-lg font-semibold text-[#1E1E1E] mb-3 md:mb-4">
                {activeTab === "petroliferos" && "Produtos petrolíferos"}
                {activeTab === "gas" && "Produtos de Gás Natural"}
                {activeTab === "eventos" && "Produtos para eventos"}
              </h3>
              <div className="flex flex-col gap-4 md:gap-6">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt="Produto de investimento"
                  className="w-full h-[180px] md:h-[200px] lg:w-[300px] object-cover rounded-xl"
                />
                <div className="flex-1 space-y-3 md:space-y-4">
                  <div className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20">
                    <div className="flex items-center gap-2 text-[#5E6B6B]">
                      <RefreshCw className="w-3.5 h-3.5 md:w-4 md:h-4" />
                      <span className="text-xs md:text-sm">Invista dinheiro</span>
                    </div>
                    <span className="text-sm md:text-base font-semibold text-[#1E1E1E]">~ {product.investment}</span>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20">
                    <div className="flex items-center gap-2 text-[#5E6B6B]">
                      <Clock className="w-3.5 h-3.5 md:w-4 md:h-4" />
                      <span className="text-xs md:text-sm">Dias de Renda</span>
                    </div>
                    <span className="text-sm md:text-base font-semibold text-[#1E1E1E]">{product.days} Dia</span>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20">
                    <div className="flex items-center gap-2 text-[#5E6B6B]">
                      <RefreshCw className="w-3.5 h-3.5 md:w-4 md:h-4" />
                      <span className="text-xs md:text-sm">Renda Diária</span>
                    </div>
                    <span className="text-sm md:text-base font-semibold text-[#1E1E1E]">~ {product.dailyIncome}</span>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div className="flex items-center gap-2 text-[#5E6B6B]">
                      <RefreshCw className="w-3.5 h-3.5 md:w-4 md:h-4" />
                      <span className="text-xs md:text-sm">Renda Total</span>
                    </div>
                    <span className="text-sm md:text-base font-semibold text-[#1E1E1E]">~ {product.totalIncome}</span>
                  </div>
                </div>
              </div>
              <div className="flex justify-end mt-4 md:mt-6">
                <Button
                  onClick={() => handleInvest(product.investment, index)}
                  className="bg-[#0A3C3C] hover:bg-[#0C5050] text-white rounded-xl px-6 md:px-8 py-2.5 md:py-3 text-xs md:text-sm font-medium transition-colors"
                >
                  Invista agora
                  <ArrowRight className="w-3.5 h-3.5 md:w-4 md:h-4 ml-2" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {showLevelsModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-[20px] max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-[#8BA3A3]/20 px-6 py-4 flex items-center justify-between rounded-t-[20px]">
              <h2 className="text-xl font-semibold text-[#1E1E1E]">Níveis de Investimento</h2>
              <button onClick={() => setShowLevelsModal(false)} className="text-[#5E6B6B] hover:text-[#1E1E1E]">
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              {investmentLevels.map((level) => (
                <Card key={level.name} className="border-0 shadow-sm overflow-hidden">
                  <div className={`bg-gradient-to-r ${level.color} p-4 text-white`}>
                    <div className="flex items-center gap-3">
                      <Award className="w-8 h-8" />
                      <div>
                        <h3 className="text-xl font-bold">{level.name}</h3>
                        <p className="text-sm opacity-90">
                          Investimento: {level.minInvestment} BRL -{" "}
                          {level.maxInvestment ? `${level.maxInvestment} BRL` : "Ilimitado"}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 bg-white">
                    <div className="mb-3">
                      <span className="text-2xl font-bold text-[#0A3C3C]">{level.dailyReturn}</span>
                      <span className="text-sm text-[#5E6B6B] ml-2">retorno diário</span>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-semibold text-[#1E1E1E]">Benefícios:</p>
                      <ul className="space-y-1">
                        {level.benefits.map((benefit, idx) => (
                          <li key={idx} className="text-sm text-[#5E6B6B] flex items-start gap-2">
                            <span className="text-[#0A3C3C] mt-1">•</span>
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      )}

      {showInvestmentDetails && selectedProduct !== null && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setShowInvestmentDetails(false)}
        >
          <div className="bg-white rounded-[20px] max-w-md w-full p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center space-y-6">
              <div className="space-y-4">
                <label className="flex items-center justify-between py-3 px-3 border border-[#8BA3A3]/20 rounded-xl cursor-pointer hover:bg-[#F5F5F5] transition-colors">
                  <div className="flex items-center gap-2 text-[#5E6B6B]">
                    <Wallet className="w-4 h-4" />
                    <span className="text-sm">Saldo da conta</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-semibold text-[#1E1E1E]">{userBalance.toFixed(2)} BRL</span>
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="balance"
                      checked={selectedPaymentMethod === "balance"}
                      onChange={() => setSelectedPaymentMethod("balance")}
                      className="w-4 h-4 cursor-pointer"
                    />
                  </div>
                </label>
                <label className="flex items-center justify-between py-3 px-3 border border-[#8BA3A3]/20 rounded-xl cursor-pointer hover:bg-[#F5F5F5] transition-colors">
                  <div className="flex items-center gap-2 text-[#5E6B6B]">
                    <RefreshCw className="w-4 h-4" />
                    <span className="text-sm">Retirada</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-semibold text-[#1E1E1E]">0 BRL</span>
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="withdrawal"
                      checked={selectedPaymentMethod === "withdrawal"}
                      onChange={() => setSelectedPaymentMethod("withdrawal")}
                      className="w-4 h-4 cursor-pointer"
                    />
                  </div>
                </label>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowInvestmentDetails(false)}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-[#8BA3A3] hover:bg-[#7A9292] text-white font-medium transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleConfirmDetails}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-[#0A3C3C] hover:bg-[#0C5050] text-white font-medium transition-colors"
                >
                  Confirmar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showInsufficientBalance && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setShowInsufficientBalance(false)}
        >
          <div className="bg-white rounded-[20px] max-w-md w-full p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
                <Wallet className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-[#1E1E1E] mb-2">Saldo Insuficiente</h3>
              <p className="text-sm text-[#5E6B6B] mb-6">
                Você não tem saldo suficiente para realizar este investimento. O valor mínimo de depósito é de R$ 50,00.
                Por favor, recarregue sua carteira.
              </p>
              <button
                onClick={handleRecharge}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0A3C3C] hover:bg-[#0C5050] text-white font-medium transition-colors"
              >
                Recarregar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fixed Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 md:px-8 py-3 md:py-4 rounded-t-[30px] md:rounded-none">
        <div className="max-w-7xl mx-auto flex items-center justify-around">
          <Link
            href="/casa"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Home className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">casa</span>
          </Link>
          <Link
            href="/"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white hover:text-white transition-colors"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white flex items-center justify-center hover:bg-white/90 transition-colors">
              <BarChart3 className="w-5 h-5 md:w-6 md:h-6 text-[#0A3C3C]" />
            </div>
            <span className="text-[10px] md:text-xs font-medium">Investir</span>
          </Link>
          <Link
            href="/clube"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Users className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">Clube</span>
          </Link>
          <Link
            href="/blog"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <BookOpen className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">Blog</span>
          </Link>
          <Link
            href="/nossa-historia"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Info className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">NossaHistória</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
