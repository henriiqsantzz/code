"use client"

import { useState } from "react"
import {
  Users,
  DollarSign,
  Activity,
  Search,
  Filter,
  Download,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  ArrowLeft,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function AdminPanel() {
  const [activeSection, setActiveSection] = useState<"dashboard" | "users" | "investments" | "withdrawals">("dashboard")
  const [searchTerm, setSearchTerm] = useState("")

  // Mock data
  const stats = {
    totalUsers: 1247,
    activeInvestments: 856,
    totalInvested: 2847650,
    pendingWithdrawals: 23,
  }

  const recentUsers = [
    {
      id: 1,
      name: "João Silva",
      email: "joao@email.com",
      balance: 1250,
      level: "Prata",
      status: "active",
      joinDate: "2025-10-15",
    },
    {
      id: 2,
      name: "Maria Santos",
      email: "maria@email.com",
      balance: 5800,
      level: "Ouro",
      status: "active",
      joinDate: "2025-10-12",
    },
    {
      id: 3,
      name: "Pedro Costa",
      email: "pedro@email.com",
      balance: 450,
      level: "Bronze",
      status: "active",
      joinDate: "2025-10-20",
    },
  ]

  const recentInvestments = [
    { id: 1, user: "João Silva", product: "Produtos petrolíferos", amount: 80, date: "2025-10-31", status: "active" },
    { id: 2, user: "Maria Santos", product: "Gás Natural", amount: 150, date: "2025-10-31", status: "active" },
    { id: 3, user: "Pedro Costa", product: "Produtos petrolíferos", amount: 40, date: "2025-10-30", status: "active" },
  ]

  const pendingWithdrawals = [
    { id: 1, user: "Ana Lima", amount: 250, date: "2025-10-31 14:30", status: "pending" },
    { id: 2, user: "Carlos Souza", amount: 500, date: "2025-10-31 13:15", status: "pending" },
    { id: 3, user: "Beatriz Alves", amount: 180, date: "2025-10-31 12:00", status: "pending" },
  ]

  const handleApproveWithdrawal = (id: number) => {
    console.log("[v0] Approving withdrawal:", id)
  }

  const handleRejectWithdrawal = (id: number) => {
    console.log("[v0] Rejecting withdrawal:", id)
  }

  return (
    <div className="min-h-screen bg-[#C1D7D7]">
      {/* Header */}
      <header className="bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 md:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/casa">
              <Button variant="ghost" className="text-white hover:bg-white/10">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl md:text-2xl font-bold text-white">Painel Administrativo</h1>
          </div>
          <div className="text-white text-sm">
            Admin: <span className="font-semibold">Sistema</span>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-[#8BA3A3]/20 px-4 md:px-8">
        <div className="flex gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveSection("dashboard")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "dashboard"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveSection("users")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "users"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Usuários
          </button>
          <button
            onClick={() => setActiveSection("investments")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "investments"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Investimentos
          </button>
          <button
            onClick={() => setActiveSection("withdrawals")}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeSection === "withdrawals"
                ? "border-[#0A3C3C] text-[#0A3C3C]"
                : "border-transparent text-[#5E6B6B] hover:text-[#0A3C3C]"
            }`}
          >
            Saques Pendentes
            {pendingWithdrawals.length > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">
                {pendingWithdrawals.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 md:px-8 py-6">
        {/* Dashboard Section */}
        {activeSection === "dashboard" && (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Total de Usuários</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">{stats.totalUsers}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Investimentos Ativos</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">{stats.activeInvestments}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                    <Activity className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Total Investido</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">
                      {stats.totalInvested.toLocaleString("pt-BR")} BRL
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-[#0A3C3C]/10 flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-[#0A3C3C]" />
                  </div>
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-[#5E6B6B]">Saques Pendentes</p>
                    <p className="text-2xl font-bold text-[#1E1E1E] mt-1">{stats.pendingWithdrawals}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center">
                    <Clock className="w-6 h-6 text-orange-600" />
                  </div>
                </div>
              </Card>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <h3 className="text-lg font-semibold text-[#1E1E1E] mb-4">Usuários Recentes</h3>
                <div className="space-y-3">
                  {recentUsers.slice(0, 5).map((user) => (
                    <div
                      key={user.id}
                      className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20 last:border-0"
                    >
                      <div>
                        <p className="text-sm font-medium text-[#1E1E1E]">{user.name}</p>
                        <p className="text-xs text-[#5E6B6B]">{user.email}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-[#0A3C3C]">{user.balance} BRL</p>
                        <p className="text-xs text-[#5E6B6B]">{user.level}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="bg-white rounded-xl p-6 border-0 shadow-sm">
                <h3 className="text-lg font-semibold text-[#1E1E1E] mb-4">Investimentos Recentes</h3>
                <div className="space-y-3">
                  {recentInvestments.slice(0, 5).map((investment) => (
                    <div
                      key={investment.id}
                      className="flex items-center justify-between py-2 border-b border-[#8BA3A3]/20 last:border-0"
                    >
                      <div>
                        <p className="text-sm font-medium text-[#1E1E1E]">{investment.user}</p>
                        <p className="text-xs text-[#5E6B6B]">{investment.product}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-[#0A3C3C]">{investment.amount} BRL</p>
                        <p className="text-xs text-[#5E6B6B]">{investment.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        )}

        {/* Users Section */}
        {activeSection === "users" && (
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5E6B6B]" />
                <input
                  type="text"
                  placeholder="Buscar usuários..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-xl border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
                />
              </div>
              <div className="flex gap-2">
                <Button className="bg-white text-[#0A3C3C] border border-[#8BA3A3]/20 hover:bg-[#8BA3A3]/10">
                  <Filter className="w-4 h-4 mr-2" />
                  Filtrar
                </Button>
                <Button className="bg-[#0A3C3C] text-white hover:bg-[#0C5050]">
                  <Download className="w-4 h-4 mr-2" />
                  Exportar
                </Button>
              </div>
            </div>

            <Card className="bg-white rounded-xl border-0 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#8BA3A3]/10">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Usuário</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Saldo</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Nível</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">
                        Data de Cadastro
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#8BA3A3]/20">
                    {recentUsers.map((user) => (
                      <tr key={user.id} className="hover:bg-[#8BA3A3]/5">
                        <td className="px-6 py-4 text-sm font-medium text-[#1E1E1E]">{user.name}</td>
                        <td className="px-6 py-4 text-sm text-[#5E6B6B]">{user.email}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-[#0A3C3C]">{user.balance} BRL</td>
                        <td className="px-6 py-4 text-sm">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${
                              user.level === "Ouro"
                                ? "bg-yellow-100 text-yellow-800"
                                : user.level === "Prata"
                                  ? "bg-gray-100 text-gray-800"
                                  : "bg-orange-100 text-orange-800"
                            }`}
                          >
                            {user.level}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-[#5E6B6B]">{user.joinDate}</td>
                        <td className="px-6 py-4 text-sm">
                          <Button variant="ghost" size="sm" className="text-[#0A3C3C] hover:bg-[#0A3C3C]/10">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* Investments Section */}
        {activeSection === "investments" && (
          <div className="space-y-4">
            <Card className="bg-white rounded-xl border-0 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#8BA3A3]/10">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Usuário</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Produto</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Valor</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Data</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#8BA3A3]/20">
                    {recentInvestments.map((investment) => (
                      <tr key={investment.id} className="hover:bg-[#8BA3A3]/5">
                        <td className="px-6 py-4 text-sm font-medium text-[#1E1E1E]">{investment.user}</td>
                        <td className="px-6 py-4 text-sm text-[#5E6B6B]">{investment.product}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-[#0A3C3C]">{investment.amount} BRL</td>
                        <td className="px-6 py-4 text-sm text-[#5E6B6B]">{investment.date}</td>
                        <td className="px-6 py-4 text-sm">
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Ativo
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <Button variant="ghost" size="sm" className="text-[#0A3C3C] hover:bg-[#0A3C3C]/10">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* Withdrawals Section */}
        {activeSection === "withdrawals" && (
          <div className="space-y-4">
            <Card className="bg-white rounded-xl border-0 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#8BA3A3]/10">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Usuário</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Valor</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Data/Hora</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-[#5E6B6B] uppercase">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#8BA3A3]/20">
                    {pendingWithdrawals.map((withdrawal) => (
                      <tr key={withdrawal.id} className="hover:bg-[#8BA3A3]/5">
                        <td className="px-6 py-4 text-sm font-medium text-[#1E1E1E]">{withdrawal.user}</td>
                        <td className="px-6 py-4 text-sm font-semibold text-[#0A3C3C]">{withdrawal.amount} BRL</td>
                        <td className="px-6 py-4 text-sm text-[#5E6B6B]">{withdrawal.date}</td>
                        <td className="px-6 py-4 text-sm">
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                            Pendente
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <div className="flex gap-2">
                            <Button
                              onClick={() => handleApproveWithdrawal(withdrawal.id)}
                              size="sm"
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Aprovar
                            </Button>
                            <Button
                              onClick={() => handleRejectWithdrawal(withdrawal.id)}
                              size="sm"
                              className="bg-red-600 hover:bg-red-700 text-white"
                            >
                              <XCircle className="w-4 h-4 mr-1" />
                              Rejeitar
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
