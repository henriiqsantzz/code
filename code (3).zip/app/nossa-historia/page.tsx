"use client"

import { Home, BarChart3, Users, BookOpen, Info, MessageCircle, Send, ArrowRight } from "lucide-react"
import { Card } from "@/components/ui/card"
import Link from "next/link"

export default function NossaHistoriaPage() {
  return (
    <div className="min-h-screen bg-[#C1D7D7] pb-24">
      {/* Hero Image */}
      <div className="w-full h-64 md:h-80 relative overflow-hidden">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-j0yUXFhsL84Sx9eNbV2qGvnCGdmp8n.png"
          alt="Business meeting"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Customer Service Cards */}
      <div className="px-4 -mt-20 mb-6 relative z-10">
        <Card className="bg-white rounded-2xl p-4 shadow-lg border-0 flex items-center gap-3 mb-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center flex-shrink-0">
            <MessageCircle className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-[#1E1E1E] mb-0.5">Atendimento ao Cliente Online</h4>
            <p className="text-xs text-[#5E6B6B]">
              Horário de atendimento ao cliente online a partir de 09:00:00 para 20:00:00.
            </p>
          </div>
          <ArrowRight className="w-5 h-5 text-[#5E6B6B] flex-shrink-0" />
        </Card>

        <Card className="bg-white rounded-2xl p-4 shadow-lg border-0 flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-[#0088cc] flex items-center justify-center flex-shrink-0">
            <Send className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-[#1E1E1E] mb-0.5">Canal do Telegram</h4>
            <p className="text-xs text-[#5E6B6B]">
              Últimas notificações e anúncios, novas informações sobre benefícios e, às vezes, presentes misteriosos!
            </p>
          </div>
          <ArrowRight className="w-5 h-5 text-[#5E6B6B] flex-shrink-0" />
        </Card>
      </div>

      {/* About Us Content */}
      <div className="px-4 mb-6">
        <Card className="bg-white rounded-2xl p-6 shadow-sm border-0">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#8BA3A3]/20">
            <div className="w-1 h-6 bg-[#0A3C3C] rounded-full"></div>
            <h2 className="text-lg font-bold text-[#1E1E1E]">Sobre nós</h2>
          </div>

          <div className="space-y-4 text-sm text-[#1E1E1E] leading-relaxed">
            <p>
              A Agência Internacional de Energia (AIE) anunciou recentemente que o governo brasileiro apresentou seu
              pedido de adesão plena por via diplomática formal. Em setembro, na sede da AIE em Paris, o Embaixador do
              Brasil na França, J.B. Sarquis, apresentou uma carta assinada pelo Ministro das Relações Exteriores do
              Brasil, Mauro Vieira, e pelo Ministro de Minas e Energia, Alexandre Silveira, ao Diretor Executivo da AIE,
              Fatih Birol. Esta carta marca um passo crucial para o Brasil, a maior economia da América Latina, na
              governança energética global.
            </p>

            <p>
              Na carta, o governo brasileiro elogiou sua parceria de longa data com a AIE. Ambos os ministros afirmaram
              que os anos de colaboração do Brasil com a AIE contribuíram significativamente para o avanço da política
              energética brasileira. Enfatizaram também que, diante dos desafios do futuro cenário energético e do apoio
              estratégico que a AIE oferece aos seus países-membros, o Brasil espera ingressar formalmente na AIE para,
              em conjunto, abordar questões energéticas globais.
            </p>

            <p>
              Desde que se juntou à Agência Internacional de Energia (AIE) como País Associado em 2017, o Brasil e a AIE
              têm aprofundado sua cooperação em áreas como segurança energética, estatísticas de dados e análise de
              políticas. Em 2024, a AIE realizou uma avaliação abrangente da política energética do Brasil, aprofundando
              o diálogo político entre as duas partes. Embora seja exportador de petróleo, o Brasil possui uma matriz
              energética diversificada e é líder em energia limpa e renovável, especialmente biocombustíveis. Sua adesão
              injetará um novo ímpeto no trabalho da AIE e na governança energética global.
            </p>

            <p>
              Birol acolheu a candidatura do Brasil, classificando-a como um avanço significativo na governança
              energética internacional e dando continuidade à cooperação bilateral de longa data. Ele enfatizou que o
              Brasil não é apenas um líder na economia da América Latina, mas também um pilar fundamental do sistema
              energético global. Por exemplo, o Brasil é um grande produtor e exportador de petróleo, contribuindo para
              a segurança energética internacional. O país também é pioneiro na transição energética, alavancando seu
              sistema energético de baixo carbono, principalmente hidrelétrico, seus abundantes recursos eólicos e
              solares e uma indústria de biocombustíveis líder mundial, para alcançar resultados significativos na
              promoção do desenvolvimento de baixo carbono e do crescimento econômico inclusivo.
            </p>

            <p>
              Birol também destacou que o Brasil ocupa atualmente a presidência da 30ª Conferência das Nações Unidas
              sobre Mudanças Climáticas (COP30), em 2025, e a presidência rotativa do Grupo dos Vinte (G20), em 2024,
              desempenhando um papel central de coordenação na agenda internacional de energia e clima. A AIE espera
              trabalhar com o Brasil e outros países-membros para avançar no trabalho e ajudar a governança energética
              global a caminhar em uma direção mais eficiente e sustentável.
            </p>

            <p>
              Como o maior país da América do Sul, o Brasil ocupa uma posição única no cenário energético global. Sua
              produção de petróleo bruto está entre as mais altas do mundo, contribuindo para a estabilidade do mercado
              internacional de petróleo por meio de exportações. Com as energias renováveis representando mais de 40% de
              sua matriz energética, o Brasil oferece uma referência valiosa para a transição global para uma economia
              de baixo carbono. A adesão do Brasil à representação de mercados emergentes e economias em desenvolvimento
              entre os membros da AIE e promoverá o desenvolvimento de uma estrutura mais inclusiva para a cooperação
              internacional em segurança energética.
            </p>

            <p>
              A AIE conta atualmente com 32 membros plenos, com outros quatro em processo de adesão, e 13 membros
              associados, incluindo China e Índia. Se o Brasil ingressar com sucesso na AIE, a organização se tornará
              uma importante ponte de ligação entre a governança energética no Sul e no Norte globais e promoverá o
              desenvolvimento de um sistema energético global mais equilibrado e sustentável.
            </p>
          </div>
        </Card>
      </div>

      {/* Fixed Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 md:px-8 py-3 md:py-4 rounded-t-[30px] md:rounded-none">
        <div className="max-w-7xl mx-auto flex items-center justify-around">
          <Link
            href="/casa"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Home className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">casa</span>
          </Link>
          <Link
            href="/"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors">
              <BarChart3 className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
            <span className="text-[10px] md:text-xs font-medium">Investir</span>
          </Link>
          <Link
            href="/clube"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <Users className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">Clube</span>
          </Link>
          <Link
            href="/blog"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white/70 hover:text-white transition-colors"
          >
            <BookOpen className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-[10px] md:text-xs font-medium">Blog</span>
          </Link>
          <Link
            href="/nossa-historia"
            className="flex flex-col items-center gap-0.5 md:gap-1 text-white hover:text-white transition-colors"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white flex items-center justify-center hover:bg-white/90 transition-colors">
              <Info className="w-5 h-5 md:w-6 md:h-6 text-[#0A3C3C]" />
            </div>
            <span className="text-[10px] md:text-xs font-medium">NossaHistória</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
