"use client"

import { useEffect, useState } from "react"
import { useUser } from "@/lib/hooks/use-user"
import { createClient } from "@/lib/supabase/client"
import { ArrowLeft, Receipt, Calendar, Search } from "lucide-react"
import { Card } from "@/components/ui/card"
import Link from "next/link"

export default function DepositosPage() {
  const { user, loading: userLoading } = useUser()
  const [deposits, setDeposits] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    if (user) {
      fetchDeposits()
    }
  }, [user])

  const fetchDeposits = async () => {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("deposits")
      .select("*")
      .eq("user_id", user?.id)
      .order("created_at", { ascending: false })

    if (!error && data) {
      setDeposits(data)
    }
    setLoading(false)
  }

  const filteredDeposits = deposits.filter(
    (deposit) => deposit.amount.toString().includes(searchTerm) || deposit.transaction_id?.includes(searchTerm),
  )

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return { bg: "bg-green-100", text: "text-green-700", label: "Concluído" }
      case "pending":
        return { bg: "bg-orange-100", text: "text-orange-700", label: "Pendente" }
      case "failed":
        return { bg: "bg-red-100", text: "text-red-700", label: "Falhou" }
      default:
        return { bg: "bg-gray-100", text: "text-gray-700", label: status }
    }
  }

  return (
    <div className="min-h-screen bg-[#C1D7D7] pb-24">
      {/* Header */}
      <header className="bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 py-4">
        <div className="flex items-center gap-3">
          <Link href="/casa">
            <button className="text-white">
              <ArrowLeft className="w-6 h-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold text-white">Registros de Depósito</h1>
        </div>
      </header>

      {/* Search */}
      <div className="px-4 py-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5E6B6B]" />
          <input
            type="text"
            placeholder="Buscar por valor ou transação..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-[#8BA3A3]/20 focus:outline-none focus:border-[#0A3C3C]"
          />
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-4 space-y-4">
        {userLoading || loading ? (
          <Card className="bg-white rounded-xl p-8 border-0 shadow-sm text-center">
            <div className="w-8 h-8 border-4 border-[#8BA3A3]/20 border-t-[#0A3C3C] rounded-full animate-spin mx-auto"></div>
            <p className="text-sm text-[#5E6B6B] mt-3">Carregando...</p>
          </Card>
        ) : filteredDeposits.length > 0 ? (
          filteredDeposits.map((deposit) => {
            const status = getStatusColor(deposit.status)
            return (
              <Card key={deposit.id} className="bg-white rounded-xl p-4 border-0 shadow-sm">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <Receipt className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-[#1E1E1E]">Depósito - {deposit.payment_method}</p>
                      <div className="flex items-center gap-1 text-xs text-[#5E6B6B] mt-0.5">
                        <Calendar className="w-3 h-3 flex-shrink-0" />
                        <span>
                          {new Date(deposit.created_at).toLocaleDateString("pt-BR", {
                            hour: "2-digit",
                            minute: "2-digit",
                          } as any)}
                        </span>
                      </div>
                      <p className="text-xs text-[#8BA3A3] mt-1 truncate">ID: {deposit.transaction_id}</p>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0 ml-2">
                    <p className="text-lg font-bold text-green-600">+R$ {deposit.amount.toFixed(2)}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${status.bg} ${status.text} inline-block`}>
                      {status.label}
                    </span>
                  </div>
                </div>
              </Card>
            )
          })
        ) : (
          <Card className="bg-white rounded-xl p-8 border-0 shadow-sm text-center">
            <Receipt className="w-12 h-12 text-[#8BA3A3] mx-auto mb-3" />
            <p className="text-sm text-[#5E6B6B]">
              {searchTerm ? "Nenhum resultado encontrado" : "Nenhum depósito encontrado"}
            </p>
          </Card>
        )}
      </div>
    </div>
  )
}
