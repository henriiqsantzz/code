"use client"

import { ArrowLeft, FileText, Calendar } from "lucide-react"
import { Card } from "@/components/ui/card"
import Link from "next/link"

export default function DetalhesFaturaPage() {
  // Mock data
  const invoices = [
    { id: 1, type: "Depósito", amount: 500, date: "2025-10-30 14:30", status: "Concluído" },
    { id: 2, type: "Investimento", amount: -80, date: "2025-10-29 10:15", status: "Concluído" },
    { id: 3, type: "Rendimento", amount: 10, date: "2025-10-28 08:00", status: "Concluído" },
  ]

  return (
    <div className="min-h-screen bg-[#C1D7D7]">
      {/* Header */}
      <header className="bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 py-4">
        <div className="flex items-center gap-3">
          <Link href="/casa">
            <button className="text-white">
              <ArrowLeft className="w-6 h-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold text-white">Detalhes da Fatura</h1>
        </div>
      </header>

      {/* Content */}
      <div className="px-4 py-6 space-y-4">
        {invoices.length > 0 ? (
          invoices.map((invoice) => (
            <Card key={invoice.id} className="bg-white rounded-xl p-4 border-0 shadow-sm">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      invoice.amount > 0 ? "bg-green-100" : "bg-red-100"
                    }`}
                  >
                    <FileText className={`w-5 h-5 ${invoice.amount > 0 ? "text-green-600" : "text-red-600"}`} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-[#1E1E1E]">{invoice.type}</p>
                    <div className="flex items-center gap-1 text-xs text-[#5E6B6B] mt-0.5">
                      <Calendar className="w-3 h-3" />
                      <span>{invoice.date}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-lg font-bold ${invoice.amount > 0 ? "text-green-600" : "text-red-600"}`}>
                    {invoice.amount > 0 ? "+" : ""}
                    {invoice.amount} BRL
                  </p>
                  <span className="text-xs text-[#5E6B6B]">{invoice.status}</span>
                </div>
              </div>
            </Card>
          ))
        ) : (
          <Card className="bg-white rounded-xl p-8 border-0 shadow-sm text-center">
            <FileText className="w-12 h-12 text-[#8BA3A3] mx-auto mb-3" />
            <p className="text-sm text-[#5E6B6B]">Nenhum registro encontrado</p>
          </Card>
        )}
      </div>
    </div>
  )
}
