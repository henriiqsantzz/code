"use client"

import { ArrowLeft, Percent, Calendar, Users } from "lucide-react"
import { Card } from "@/components/ui/card"
import Link from "next/link"

export default function ComissoesPage() {
  // Mock data
  const commissions = [
    { id: 1, amount: 15, date: "2025-10-30 12:00", from: "João Silva", level: "Nível 1 (30%)" },
    { id: 2, amount: 8, date: "2025-10-29 15:30", from: "Maria Santos", level: "Nível 2 (4%)" },
  ]

  return (
    <div className="min-h-screen bg-[#C1D7D7]">
      {/* Header */}
      <header className="bg-gradient-to-r from-[#0A3C3C] to-[#0C5050] px-4 py-4">
        <div className="flex items-center gap-3">
          <Link href="/casa">
            <button className="text-white">
              <ArrowLeft className="w-6 h-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold text-white">Registros de Comissão</h1>
        </div>
      </header>

      {/* Content */}
      <div className="px-4 py-6 space-y-4">
        {commissions.length > 0 ? (
          commissions.map((commission) => (
            <Card key={commission.id} className="bg-white rounded-xl p-4 border-0 shadow-sm">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                    <Percent className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-[#1E1E1E]">Comissão - {commission.level}</p>
                    <div className="flex items-center gap-1 text-xs text-[#5E6B6B] mt-0.5">
                      <Users className="w-3 h-3" />
                      <span>De: {commission.from}</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-[#5E6B6B] mt-0.5">
                      <Calendar className="w-3 h-3" />
                      <span>{commission.date}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-green-600">+{commission.amount} BRL</p>
                </div>
              </div>
            </Card>
          ))
        ) : (
          <Card className="bg-white rounded-xl p-8 border-0 shadow-sm text-center">
            <Percent className="w-12 h-12 text-[#8BA3A3] mx-auto mb-3" />
            <p className="text-sm text-[#5E6B6B]">Nenhum registro encontrado</p>
          </Card>
        )}
      </div>
    </div>
  )
}
