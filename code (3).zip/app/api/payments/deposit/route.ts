import { type NextRequest, NextResponse } from "next/server"

// CHANGE: API route para processar depósitos via PIX
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const { amount, paymentMethod, customerData, metadata } = body

    // Validação básica
    if (!amount || amount < 40 || amount > 50000) {
      return NextResponse.json(
        { success: false, message: "Valor inválido. Mínimo: R$40, Máximo: R$50.000" },
        { status: 400 },
      )
    }

    if (paymentMethod !== "PIX") {
      return NextResponse.json({ success: false, message: "Método de pagamento não suportado" }, { status: 400 })
    }

    // TODO: Integrar com API real de pagamento (wopay, Stripe, etc)
    // Aqui você faria a chamada para sua API de PIX

    // Simulação de sucesso
    const transactionId = `txn_${Date.now()}`
    const externalTransactionId = `ext_${Math.random().toString(36).substr(2, 9)}`

    console.log("[v0] Deposit request processed:", {
      transactionId,
      amount,
      customerData,
      metadata,
    })

    return NextResponse.json({
      success: true,
      message: "Depósito iniciado com sucesso",
      data: {
        transactionId,
        externalTransactionId,
        status: "PENDING",
        amount,
        paymentMethod,
        createdAt: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error("[v0] Deposit error:", error)
    return NextResponse.json({ success: false, message: "Erro ao processar depósito" }, { status: 500 })
  }
}
