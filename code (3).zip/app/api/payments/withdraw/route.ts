import { type NextRequest, NextResponse } from "next/server"

// CHANGE: API route para processar saques via PIX
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const { amount, pixKey, pixKeyType } = body

    // Validação básica
    if (!amount || amount < 50) {
      return NextResponse.json({ success: false, message: "Valor mínimo de saque é R$50" }, { status: 400 })
    }

    if (!pixKey || !pixKeyType) {
      return NextResponse.json({ success: false, message: "Chave PIX e tipo são obrigatórios" }, { status: 400 })
    }

    // TODO: Integrar com API real de pagamento
    // Aqui você faria a chamada para sua API de PIX para processar o saque

    // Simulação de sucesso
    const transactionId = `txn_${Date.now()}`
    const externalTransactionId = `ext_${Math.random().toString(36).substr(2, 9)}`
    const amountFee = amount * 0.025 // 2.5% de taxa
    const amountNet = amount - amountFee

    console.log("[v0] Withdraw request processed:", {
      transactionId,
      amount,
      pixKey,
      pixKeyType,
    })

    return NextResponse.json({
      success: true,
      message: "Saque processado com sucesso",
      data: {
        transactionId,
        externalTransactionId,
        status: "PENDING",
        amount,
        amountNet,
        amountFee,
        paymentMethod: "PIX",
        pixKey,
        pixKeyType,
        createdAt: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error("[v0] Withdraw error:", error)
    return NextResponse.json({ success: false, message: "Erro ao processar saque" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    // TODO: Implementar endpoint GET para buscar status de saques
    return NextResponse.json({
      success: true,
      message: "Endpoint GET de saques",
    })
  } catch (error) {
    console.error("[v0] GET Withdraw error:", error)
    return NextResponse.json({ success: false, message: "Erro ao buscar saques" }, { status: 500 })
  }
}
